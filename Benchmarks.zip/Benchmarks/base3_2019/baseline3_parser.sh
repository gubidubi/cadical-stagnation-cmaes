awk '
/c --- \[ banner \]/ {
    if (file != "") print file, (res ? res : "UNKNOWN"), (time ? time : "TIMEOUT")
    file = $1; sub(/^\+\]/, "", file)
    time = ""; res = ""
}
/^s (SATISFIABLE|UNSATISFIABLE)/ || /^c UNKNOWN/ {
    res = $2
}
/^c total process time since initialization:/ {
    time = $7
}
END {
    if (file != "") print file, (res ? res : "UNKNOWN"), (time ? time : "TIMEOUT")
}' OFS="," fullout > summary.csv

